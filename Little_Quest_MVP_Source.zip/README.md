# Little Quest — MVP 0.1

A first playable Android-first learning game prototype for ages 3–11.

## Included
- Child adventure home with English, Mathematics and Science worlds
- Three-question sample quest with picture choices
- Gentle retry and optional hint states
- Completion celebration and star rewards
- Buddy, Sticker Book and Collection tabs
- Basic parent gate and local parent dashboard
- Local persistence for nickname, stars and completed quests

## Run locally
1. Install Flutter (stable) and Android Studio.
2. Extract this project.
3. Run `flutter pub get`
4. Run `flutter run`

## Build APK
`flutter build apk --release`

The GitHub Actions workflow in `.github/workflows/android-apk.yml` can build the APK in GitHub Actions when this folder is pushed to a GitHub repository.

## Important MVP limitations
This is a functional prototype, not a production release. The parent gate is a simple demo arithmetic check, not secure parental authentication. It does not implement verifiable parental consent, account registration, backend sync, audio narration, analytics instrumentation, billing, or production privacy controls. Do not publish or use with real children's data until those features and legal/privacy reviews are completed.
