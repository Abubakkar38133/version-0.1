import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  runApp(LittleQuestApp(prefs: prefs));
}

class LittleQuestApp extends StatelessWidget {
  final SharedPreferences prefs;
  const LittleQuestApp({super.key, required this.prefs});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Little Quest',
    theme: ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: const Color(0xFFF2F8FF),
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF438CD5)),
      fontFamily: 'Nunito',
    ),
    home: HomeScreen(prefs: prefs),
  );
}

const navy = Color(0xFF19334D);
const blue = Color(0xFF438CD5);
const green = Color(0xFF42A979);
const yellow = Color(0xFFFFD166);
const coral = Color(0xFFFF916B);
const lavender = Color(0xFFA58AE4);

class HomeScreen extends StatefulWidget {
  final SharedPreferences prefs;
  const HomeScreen({super.key, required this.prefs});
  @override State<HomeScreen> createState() => _HomeScreenState();
}
class _HomeScreenState extends State<HomeScreen> {
  int tab = 0;
  String childName = 'Explorer';
  int stars = 0;
  int completed = 0;
  bool parentUnlocked = false;

  @override void initState() {
    super.initState();
    childName = widget.prefs.getString('childName') ?? 'Explorer';
    stars = widget.prefs.getInt('stars') ?? 0;
    completed = widget.prefs.getInt('completed') ?? 0;
  }
  Future<void> save() async {
    await widget.prefs.setString('childName', childName);
    await widget.prefs.setInt('stars', stars);
    await widget.prefs.setInt('completed', completed);
  }
  void addReward() { setState(() { stars += 3; completed += 1; }); save(); }

  @override Widget build(BuildContext context) {
    final pages = [
      adventurePage(context),
      buddyPage(context),
      stickersPage(context),
      collectionPage(context),
    ];
    return Scaffold(
      body: SafeArea(child: pages[tab]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        backgroundColor: Colors.white,
        indicatorColor: const Color(0xFFDDEFFA),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.map_rounded), label: 'Adventure'),
          NavigationDestination(icon: Icon(Icons.pets_rounded), label: 'Buddy'),
          NavigationDestination(icon: Icon(Icons.auto_awesome_rounded), label: 'Stickers'),
          NavigationDestination(icon: Icon(Icons.inventory_2_rounded), label: 'Collection'),
        ],
      ),
    );
  }

  Widget adventurePage(BuildContext context) => ListView(
    padding: const EdgeInsets.fromLTRB(20, 14, 20, 24),
    children: [
      Row(children: [
        const CircleAvatar(radius: 24, backgroundColor: Color(0xFFFFE6B8), child: Text('🦊', style: TextStyle(fontSize: 27))),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Hello, $childName!', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: navy)),
          const Text('Ready for a little adventure?', style: TextStyle(color: Colors.blueGrey)),
        ])),
        _pill('⭐ $stars', yellow),
        IconButton(onPressed: showParentGate, icon: const Icon(Icons.family_restroom_rounded, color: navy), tooltip: 'Parent area'),
      ]),
      const SizedBox(height: 22),
      Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFF65B6E8), Color(0xFF438CD5)]),
          borderRadius: BorderRadius.circular(28),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('🌈  SUNNY MEADOW', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, letterSpacing: 1.1)),
          const SizedBox(height: 8),
          const Text('Your learning world\nis waiting!', style: TextStyle(color: Colors.white, fontSize: 27, fontWeight: FontWeight.w900, height: 1.15)),
          const SizedBox(height: 10),
          const Text('Tiny steps make big discoveries.', style: TextStyle(color: Colors.white)),
          const SizedBox(height: 16),
          Row(children: [
            const Text('🦊', style: TextStyle(fontSize: 64)),
            const Spacer(),
            FilledButton.icon(
              style: FilledButton.styleFrom(backgroundColor: yellow, foregroundColor: navy, padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14)),
              onPressed: () => openQuest(context),
              icon: const Icon(Icons.play_arrow_rounded),
              label: const Text('Play a quest', style: TextStyle(fontWeight: FontWeight.w900)),
            ),
          ]),
        ]),
      ),
      const SizedBox(height: 22),
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        const Text('Choose your adventure', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: navy)),
        Text('$completed quests', style: const TextStyle(color: Colors.blueGrey, fontWeight: FontWeight.w700)),
      ]),
      const SizedBox(height: 12),
      _worldCard('🔤', 'English Garden', 'Letters, words & sounds', const Color(0xFFE1F4E9), green, () => openQuest(context)),
      _worldCard('🔢', 'Number Mountain', 'Counting & little sums', const Color(0xFFFFF0CC), const Color(0xFFB77B19), () => openQuest(context)),
      _worldCard('🔬', 'Wonder Woods', 'Discover the world around you', const Color(0xFFECE6FF), lavender, () => openQuest(context)),
      const SizedBox(height: 18),
      const Text('Your path', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: navy)),
      const SizedBox(height: 10),
      Row(children: [
        _pathDot('1', green, true), const Expanded(child: Divider(thickness: 3, color: Color(0xFFB7DEC8))),
        _pathDot('2', blue, false), const Expanded(child: Divider(thickness: 3, color: Color(0xFFD7E2EC))),
        _pathDot('3', Colors.white, false),
      ]),
      const SizedBox(height: 8),
      const Text('Keep exploring at your own pace. Your progress stays right here.', textAlign: TextAlign.center, style: TextStyle(color: Colors.blueGrey)),
    ],
  );

  Widget _worldCard(String emoji, String title, String sub, Color bg, Color accent, VoidCallback onTap) => Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: Material(color: Colors.white, borderRadius: BorderRadius.circular(20), child: InkWell(
      borderRadius: BorderRadius.circular(20), onTap: onTap,
      child: Padding(padding: const EdgeInsets.all(15), child: Row(children: [
        Container(width: 54, height: 54, decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(16)), child: Center(child: Text(emoji, style: const TextStyle(fontSize: 29))),
        const SizedBox(width: 13),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w900, color: navy, fontSize: 16)),
          Text(sub, style: const TextStyle(color: Colors.blueGrey, fontSize: 12)),
        ])),
        Icon(Icons.arrow_forward_ios_rounded, size: 17, color: accent),
      ])),
    )),
  );

  Widget _pathDot(String t, Color c, bool done) => Container(
    width: 42, height: 42, decoration: BoxDecoration(color: c, shape: BoxShape.circle, border: Border.all(color: done ? green : const Color(0xFFD7E2EC), width: 3)),
    child: Center(child: Text(done ? '✓' : t, style: TextStyle(fontWeight: FontWeight.w900, color: c == Colors.white ? navy : Colors.white, fontSize: 17))),
  );

  Widget buddyPage(BuildContext context) => _simplePage('Meet your buddy', 'Your friendly guide is always cheering you on.', '🦊', 'I’m Pip! Let’s learn something new together.', yellow);
  Widget stickersPage(BuildContext context) => _simplePage('Sticker book', 'Every little effort deserves a celebration.', '🌟', '$stars stars collected', lavender);
  Widget collectionPage(BuildContext context) => _simplePage('My collection', 'A little treasure for every new discovery.', '🎁', '$completed quests completed', const Color(0xFFE1F4E9));
  Widget _simplePage(String title, String subtitle, String emoji, String note, Color color) => Center(child: Padding(
    padding: const EdgeInsets.all(28), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Text(emoji, style: const TextStyle(fontSize: 90)),
      const SizedBox(height: 18),
      Text(title, style: const TextStyle(fontSize: 27, fontWeight: FontWeight.w900, color: navy)),
      const SizedBox(height: 8), Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(color: Colors.blueGrey)),
      const SizedBox(height: 22),
      Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(20)), child: Text(note, style: const TextStyle(fontWeight: FontWeight.w900, color: navy, fontSize: 18))),
    ]),
  ));

  Widget _pill(String label, Color color) => Container(padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 8), decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(30)), child: Text(label, style: const TextStyle(fontWeight: FontWeight.w900, color: navy)));

  void openQuest(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (_) => QuestScreen(onComplete: addReward)));

  void showParentGate() {
    showDialog(context: context, builder: (ctx) {
      final controller = TextEditingController();
      return AlertDialog(
        title: const Text('Grown-up check'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('To enter Parent Mode, solve this little question:'),
          const SizedBox(height: 12),
          const Text('What is 3 + 2?', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 23)),
          TextField(controller: controller, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Answer')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Not now')),
          FilledButton(onPressed: () {
            if (controller.text.trim() == '5') {
              Navigator.pop(ctx);
              Navigator.push(context, MaterialPageRoute(builder: (_) => ParentScreen(name: childName, stars: stars, completed: completed, onName: (v) { setState(() => childName = v); save(); })));
            }
          }, child: const Text('Continue')),
        ],
      );
    });
  }
}

class QuestScreen extends StatefulWidget {
  final VoidCallback onComplete;
  const QuestScreen({super.key, required this.onComplete});
  @override State<QuestScreen> createState() => _QuestScreenState();
}
class _QuestScreenState extends State<QuestScreen> {
  int stage = 0;
  int selected = -1;
  bool helped = false;
  final prompts = [
    {'q':'Which one begins with the letter B?', 'emoji':['🍎','⚽','🐱'], 'answer':1, 'hint':'Listen for the first sound: buh!'},
    {'q':'Which picture is a butterfly?', 'emoji':['🦋','🐟','🌼'], 'answer':0, 'hint':'Look for the colourful wings.'},
    {'q':'What comes after 2?', 'emoji':['1','3','5'], 'answer':1, 'hint':'Count with Pip: one, two, three!'},
  ];
  @override Widget build(BuildContext context) {
    final p = prompts[stage];
    return Scaffold(
      appBar: AppBar(backgroundColor: Colors.transparent, title: Text('Little quest  •  ${stage+1} of 3', style: const TextStyle(fontWeight: FontWeight.w900, color: navy)), leading: IconButton(icon: const Icon(Icons.close_rounded), onPressed: () => Navigator.pop(context))),
      body: SafeArea(child: Padding(padding: const EdgeInsets.fromLTRB(20, 8, 20, 22), child: Column(children: [
        ClipRRect(borderRadius: BorderRadius.circular(20), child: LinearProgressIndicator(value: (stage+1)/3, minHeight: 10, backgroundColor: const Color(0xFFDDE8F1), color: green)),
        const SizedBox(height: 24),
        const Text('🦊', style: TextStyle(fontSize: 58)),
        const Text('Pip says…', style: TextStyle(color: blue, fontWeight: FontWeight.w900)),
        const SizedBox(height: 12),
        Text(p['q'] as String, textAlign: TextAlign.center, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900, color: navy)),
        const SizedBox(height: 24),
        Expanded(child: Row(children: List.generate(3, (i) => Expanded(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 5), child: InkWell(
          borderRadius: BorderRadius.circular(22), onTap: () => setState(() => selected = i),
          child: AnimatedContainer(duration: const Duration(milliseconds: 180), decoration: BoxDecoration(color: selected == i ? const Color(0xFFDDEFFA) : Colors.white, borderRadius: BorderRadius.circular(22), border: Border.all(color: selected == i ? blue : const Color(0xFFE0E8EF), width: selected == i ? 3 : 1)),
            child: Center(child: Text((p['emoji'] as List<String>)[i], style: const TextStyle(fontSize: 48))),
          ),
        ))))),
        if (helped) Container(width: double.infinity, padding: const EdgeInsets.all(13), margin: const EdgeInsets.only(bottom: 12), decoration: BoxDecoration(color: const Color(0xFFFFF0CC), borderRadius: BorderRadius.circular(15)), child: Text(p['hint'] as String, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w700, color: navy))),
        if (selected >= 0) Container(width: double.infinity, padding: const EdgeInsets.all(13), margin: const EdgeInsets.only(bottom: 12), decoration: BoxDecoration(color: selected == p['answer'] ? const Color(0xFFE1F4E9) : const Color(0xFFFFF0CC), borderRadius: BorderRadius.circular(15)), child: Text(selected == p['answer'] ? 'Wonderful choosing! 🌟' : 'Good try! Want a little hint?', textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w900, color: navy))),
        Row(children: [
          Expanded(child: OutlinedButton(onPressed: () => setState(() => helped = true), child: const Text('💡 Hint'))),
          const SizedBox(width: 10),
          Expanded(flex: 2, child: FilledButton(
            style: FilledButton.styleFrom(backgroundColor: green, padding: const EdgeInsets.symmetric(vertical: 16)),
            onPressed: selected < 0 ? null : () {
              if (selected != p['answer']) { setState(() => helped = true); return; }
              if (stage < 2) setState(() { stage++; selected = -1; helped = false; });
              else { widget.onComplete(); Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const QuestDoneScreen())); }
            },
            child: Text(stage == 2 ? 'Finish quest' : 'Continue', style: const TextStyle(fontWeight: FontWeight.w900)),
          )),
        ]),
      ]))),
    );
  }
}
class QuestDoneScreen extends StatelessWidget {
  const QuestDoneScreen({super.key});
  @override Widget build(BuildContext context) => Scaffold(body: Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
    const Text('🎉', style: TextStyle(fontSize: 100)),
    const Text('You did it!', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900, color: navy)),
    const SizedBox(height: 8), const Text('Pip is proud of you. You earned 3 stars!', textAlign: TextAlign.center, style: TextStyle(fontSize: 18, color: Colors.blueGrey)),
    const SizedBox(height: 24), const Text('⭐  ⭐  ⭐', style: TextStyle(fontSize: 38)),
    const SizedBox(height: 28), SizedBox(width: double.infinity, child: FilledButton(onPressed: () => Navigator.pop(context), style: FilledButton.styleFrom(backgroundColor: green, padding: const EdgeInsets.all(17)), child: const Text('Back to adventure', style: TextStyle(fontWeight: FontWeight.w900)))),
  ]))));
}
class ParentScreen extends StatelessWidget {
  final String name; final int stars; final int completed; final ValueChanged<String> onName;
  const ParentScreen({super.key, required this.name, required this.stars, required this.completed, required this.onName});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Parent dashboard', style: TextStyle(fontWeight: FontWeight.w900, color: navy))),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      const Text('A gentle look at learning progress', style: TextStyle(color: Colors.blueGrey)),
      const SizedBox(height: 18),
      Row(children: [
        _metric('Quests completed', '$completed', green),
        const SizedBox(width: 10), _metric('Stars earned', '$stars', const Color(0xFFB77B19)),
      ]),
      const SizedBox(height: 20),
      const Text('Learning areas', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: navy)),
      _progress('English', completed > 0 ? 0.34 : 0.05, green),
      _progress('Mathematics', 0.12, blue),
      _progress('Science', 0.08, lavender),
      const SizedBox(height: 20),
      const Text('Child profile', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: navy)),
      ListTile(leading: const Icon(Icons.face_rounded), title: Text(name), subtitle: const Text('Local demo profile'), trailing: const Icon(Icons.edit_note_rounded), onTap: () {
        final c = TextEditingController(text: name);
        showDialog(context: context, builder: (ctx) => AlertDialog(title: const Text('Child nickname'), content: TextField(controller: c), actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(onPressed: () { onName(c.text.trim().isEmpty ? 'Explorer' : c.text.trim()); Navigator.pop(ctx); }, child: const Text('Save')),
        ]));
      }),
      const SizedBox(height: 16),
      const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('MVP note: this dashboard uses on-device demo progress. Parent accounts, verified consent, cloud sync, subscription billing and production-grade parental authentication are not yet connected.'))),
    ]),
  );
  Widget _metric(String title, String value, Color color) => Expanded(child: Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: color.withOpacity(.12), borderRadius: BorderRadius.circular(18)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(value, style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900, color: color)), Text(title, style: const TextStyle(color: navy, fontWeight: FontWeight.w700)),
  ])));
  Widget _progress(String title, double v, Color color) => Padding(padding: const EdgeInsets.symmetric(vertical: 10), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w800)), Text('${(v*100).round()}%')]),
    const SizedBox(height: 7), ClipRRect(borderRadius: BorderRadius.circular(20), child: LinearProgressIndicator(value: v, minHeight: 9, color: color, backgroundColor: color.withOpacity(.12))),
  ]));
}
