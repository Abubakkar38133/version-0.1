import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'dart:convert';

void main() => runApp(const LittleQuestApp());

const ink = Color(0xFF23324D);
const cream = Color(0xFFFFF8E9);
const green = Color(0xFF55B987);

class LittleQuestApp extends StatelessWidget {
  const LittleQuestApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Little Quest', debugShowCheckedModeBanner: false,
    theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: green), scaffoldBackgroundColor: cream, appBarTheme: const AppBarTheme(backgroundColor: cream, foregroundColor: ink, elevation: 0)),
    home: const HomePage(),
  );
}

class QuestWorld {
  final String name, emoji, subtitle;
  final Color color;
  final List<Lesson> lessons;
  const QuestWorld(this.name, this.emoji, this.subtitle, this.color, this.lessons);
}
class Lesson {
  final String title, skill;
  final List<Question> questions;
  const Lesson(this.title, this.skill, this.questions);
}
class Question {
  final String prompt, answer, hint, mascotLine;
  final List<String> choices;
  const Question(this.prompt, this.answer, this.choices, this.hint, this.mascotLine);
}

final worlds = <QuestWorld>[
  QuestWorld('English Garden', '🌻', 'Letters, words & little stories', const Color(0xFFFFE7A8), [
    Lesson('Letter explorers', 'Recognise beginning sounds', [
      Question('Which letter does BALL start with?', 'B', ['A','B','C'], 'Say the word slowly: B-B-BALL.', 'You can do it! Listen to the first sound.'),
      Question('Which word starts with S?', 'Sun', ['Cat','Sun','Dog'], 'Sun begins with the /s/ sound.', 'Let us listen for the first sound.'),
      Question('Choose the word for this picture: 🐱', 'Cat', ['Dog','Cat','Bird'], 'A cat says meow!', 'Look carefully at the picture.'),
    ]),
    Lesson('Word garden', 'Match pictures and words', [
      Question('Which one is a butterfly?', '🦋', ['🦋','🐟','🌼'], 'A butterfly has colourful wings.', 'Find the colourful wings!'),
      Question('What do we read?', 'Book', ['Shoe','Book','Cup'], 'A book has pages and a story.', 'Stories live inside books.'),
      Question('Which word rhymes with sun?', 'Fun', ['Cup','Fun','Bed'], 'Sun and fun have the same ending sound.', 'Listen to the ending sound.'),
    ]),
    Lesson('Story stars', 'Understand a tiny story', [
      Question('Mia sees rain. What can she use?', 'Umbrella', ['Umbrella','Sunglasses','Ball'], 'An umbrella helps keep us dry.', 'What do we use in the rain?'),
      Question('A bird can...', 'Fly', ['Drive','Fly','Read'], 'Birds use their wings to fly.', 'Think about wings.'),
      Question('The opposite of big is...', 'Small', ['Tall','Small','Fast'], 'Small means not big.', 'Think of a tiny mouse.'),
    ]),
  ]),
  QuestWorld('Number Mountain', '⛰️', 'Counting, patterns & maths', const Color(0xFFD8E9FF), [
    Lesson('Counting trail', 'Count objects', [
      Question('What number comes after 2?', '3', ['1','3','5'], 'Count: 1, 2, 3!', 'Let us count together.'),
      Question('How many stars? ⭐ ⭐ ⭐', '3', ['2','3','4'], 'Count each star one time.', 'Touch each star as you count.'),
      Question('What is 1 + 1?', '2', ['1','2','3'], 'One more than one makes two.', 'Imagine one apple and one more apple.'),
    ]),
    Lesson('Number bridges', 'Add small groups', [
      Question('What is 2 + 1?', '3', ['2','3','4'], 'Start at two and count one more.', 'Take one little step forward.'),
      Question('What is 3 - 1?', '2', ['1','2','3'], 'Three take away one leaves two.', 'Hide one of the three.'),
      Question('Which number is bigger?', '5', ['2','5','1'], 'Five is more than two and one.', 'Compare how far you can count.'),
    ]),
    Lesson('Pattern peak', 'Find the next pattern item', [
      Question('What comes next? 🔴 🔵 🔴 🔵 ...', '🔴', ['🔵','🔴','🟢'], 'The colours take turns: red, blue.', 'Look at the repeating pattern.'),
      Question('What comes next? 2, 4, 6, ...', '8', ['7','8','9'], 'We add two each time.', 'Count by twos.'),
      Question('Which shape has 3 sides?', 'Triangle', ['Circle','Square','Triangle'], 'A triangle has three straight sides.', 'Count the corners.'),
    ]),
  ]),
  QuestWorld('Wonder Woods', '🌳', 'Science & the world around us', const Color(0xFFDDF1D6), [
    Lesson('Living things', 'Explore plants and animals', [
      Question('Which one is a living thing?', '🌳', ['🌳','🪑','🚗'], 'A tree grows and needs water.', 'Living things grow.'),
      Question('What does a plant need?', 'Sunlight', ['Television','Sunlight','Shoes'], 'Plants use sunlight, water and air.', 'Think about what helps a plant grow.'),
      Question('Which animal lives in water?', '🐟', ['🐟','🐈','🐘'], 'Fish live and swim in water.', 'Which animal has fins?'),
    ]),
    Lesson('Our senses', 'Notice the world safely', [
      Question('Which sense helps us hear music?', 'Ears', ['Eyes','Ears','Nose'], 'We hear sounds with our ears.', 'Listen carefully.'),
      Question('Which sense helps us see colours?', 'Eyes', ['Hands','Eyes','Feet'], 'We see with our eyes.', 'Look around you.'),
      Question('Which one is a sound?', 'Bell', ['Bell','Blue','Soft'], 'A bell can ring.', 'Imagine a ringing bell.'),
    ]),
    Lesson('Earth helpers', 'Care for our planet', [
      Question('Where should paper go for recycling?', 'Recycling bin', ['River','Recycling bin','Road'], 'Recycling bins help us reuse materials.', 'Keep our neighbourhood clean.'),
      Question('What do we save by turning off a tap?', 'Water', ['Sand','Water','Clouds'], 'Turn off taps when you are not using water.', 'Every drop matters.'),
      Question('Which is kinder to a tree?', 'Protect it', ['Break branches','Protect it','Carve it'], 'Trees give shade and homes to animals.', 'Be a tree friend.'),
    ]),
  ]),
];

class HomePage extends StatefulWidget { const HomePage({super.key}); @override State<HomePage> createState()=>_HomePageState(); }
class _HomePageState extends State<HomePage> {
  final FlutterTts tts = FlutterTts();
  int tab=0, stars=0, completed=0, ageBand=0, streak=0;
  String nickname='Little Explorer';
  bool sound=true, onboardingDone=false;
  Set<String> passed={};
  @override void initState(){ super.initState(); _load(); tts.setLanguage('en-US'); tts.setSpeechRate(0.43); }
  Future<void> _load() async { final p=await SharedPreferences.getInstance(); if(!mounted)return; setState((){stars=p.getInt('stars')??0; completed=p.getInt('completed')??0; nickname=p.getString('nickname')??'Little Explorer'; ageBand=p.getInt('ageBand')??0; sound=p.getBool('sound')??true; passed=(p.getStringList('passed')??[]).toSet(); onboardingDone=p.getBool('onboardingDone')??false;}); if(!onboardingDone && mounted) WidgetsBinding.instance.addPostFrameCallback((_)=>_welcome()); }
  Future<void> _welcome() async { if(!mounted)return; final p=await SharedPreferences.getInstance(); int? age=await showDialog<int>(context:context, barrierDismissible:false,builder:(d)=>AlertDialog(title:const Text('Welcome, little explorer! 🌈'),content:const Text('Choose an age group so we can start with the right learning level.'),actions:[for(int i=0;i<3;i++) TextButton(onPressed:()=>Navigator.pop(d,i),child:Text(['Ages 3–5','Ages 6–8','Ages 9–11'][i]))])); if(age!=null){ageBand=age; onboardingDone=true; await p.setInt('ageBand',age); await p.setBool('onboardingDone',true); if(mounted)setState((){}); _say('Hello $nickname! I am Pip. Let us go on a learning adventure!');} }
  Future<void> _say(String words) async { if(!sound)return; try{await tts.stop(); await tts.speak(words);}catch(_){}}
  Future<void> _saveProgress(int earned,String key) async {final p=await SharedPreferences.getInstance(); setState((){stars+=earned;completed++;passed.add(key);}); await p.setInt('stars',stars);await p.setInt('completed',completed);await p.setStringList('passed',passed.toList());}
  Future<void> _toggleSound() async {setState(()=>sound=!sound);final p=await SharedPreferences.getInstance();await p.setBool('sound',sound);if(sound)_say('Sound is on. Let us learn!');else await tts.stop();}
  Future<void> _parentGate() async {final c=TextEditingController(); final ok=await showDialog<bool>(context:context,builder:(d)=>AlertDialog(title:const Text('Grown-up check 🔒'),content:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('To open Parent Corner, solve this: 4 + 3 = ?'),TextField(controller:c,keyboardType:TextInputType.number,decoration:const InputDecoration(hintText:'Answer'))]),actions:[TextButton(onPressed:()=>Navigator.pop(d,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(d,c.text.trim()=='7'),child:const Text('Continue'))]));if(ok==true&&mounted)setState(()=>tab=3);}
  void _openLesson(int wi,int li){final w=worlds[wi],l=w.lessons[li];Navigator.push(context,MaterialPageRoute(builder:(_)=>LessonPage(world:w,lesson:l,lessonKey:'$wi-$li',onFinish:_saveProgress,speak:_say,sound:sound)));}
  @override Widget build(BuildContext context){return Scaffold(appBar:AppBar(title:const Text('LITTLE QUEST',style:TextStyle(fontWeight:FontWeight.w900,letterSpacing:1.1)),actions:[IconButton(tooltip:sound?'Turn sound off':'Turn sound on',onPressed:_toggleSound,icon:Icon(sound?Icons.volume_up_rounded:Icons.volume_off_rounded)),Padding(padding:const EdgeInsets.only(right:16),child:Center(child:Text('⭐ $stars',style:const TextStyle(fontWeight:FontWeight.w900))))]),body:IndexedStack(index:tab,children:[_adventure(),_buddy(),_stickers(),ParentPage(nickname:nickname,stars:stars,completed:completed,ageBand:ageBand,sound:sound,onSound:_toggleSound,onName:(v)async{final p=await SharedPreferences.getInstance();await p.setString('nickname',v);setState(()=>nickname=v);},onUpdate:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const UpdatePage())))]),bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(v){if(v==3){_parentGate();}else setState(()=>tab=v);},destinations:const[NavigationDestination(icon:Icon(Icons.explore_outlined),label:'Adventure'),NavigationDestination(icon:Icon(Icons.pets_outlined),label:'Buddy'),NavigationDestination(icon:Icon(Icons.emoji_events_outlined),label:'Rewards'),NavigationDestination(icon:Icon(Icons.family_restroom),label:'Parents')]) );}
  Widget _adventure()=>ListView(padding:const EdgeInsets.fromLTRB(16,8,16,24),children:[Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(gradient:const LinearGradient(colors:[Color(0xFFBDEBD1),Color(0xFFE0F5D8)]),borderRadius:BorderRadius.circular(28)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('YOUR ADVENTURE STARTS HERE!',style:TextStyle(color:ink,fontWeight:FontWeight.w900,fontSize:17)),const SizedBox(height:6),Text('Welcome, $nickname!',style:const TextStyle(color:ink,fontSize:18)),const Center(child:Text('🦊',style:TextStyle(fontSize:76))),const Text('Hi! I am Pip. Tap me and I will help you learn!',style:TextStyle(color:ink,fontWeight:FontWeight.w600)),Align(alignment:Alignment.centerRight,child:FilledButton.tonalIcon(onPressed:()=>_say('Hi $nickname! Pick a world and let us learn together.'),icon:const Icon(Icons.volume_up),label:const Text('Talk to Pip')))])),const SizedBox(height:20),Row(children:[const Expanded(child:Text('YOUR LEARNING MAP',style:TextStyle(color:ink,fontWeight:FontWeight.w900,fontSize:18))),Text('Ages ${['3–5','6–8','9–11'][ageBand]}',style:const TextStyle(color:ink,fontWeight:FontWeight.bold))]),const SizedBox(height:10),for(int wi=0;wi<worlds.length;wi++) _worldCard(wi),const SizedBox(height:10),Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(18)),child:Row(children:[const Icon(Icons.favorite,color:Colors.pink),const SizedBox(width:10),Expanded(child:Text('$completed learning adventures completed. Every little step counts!',style:const TextStyle(color:ink,fontWeight:FontWeight.w600)))]))]);
  Widget _worldCard(int wi){final w=worlds[wi];return Card(color:w.color,elevation:0,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(22)),child:Padding(padding:const EdgeInsets.all(15),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[Text(w.emoji,style:const TextStyle(fontSize:34)),const SizedBox(width:10),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(w.name,style:const TextStyle(color:ink,fontWeight:FontWeight.w900,fontSize:17)),Text(w.subtitle,style:const TextStyle(color:ink))])),Text('${w.lessons.where((l){final i=w.lessons.indexOf(l);return passed.contains('$wi-$i');}).length}/${w.lessons.length}',style:const TextStyle(color:ink,fontWeight:FontWeight.w900))]),const SizedBox(height:12),...List.generate(w.lessons.length,(li){final l=w.lessons[li],done=passed.contains('$wi-$li'),unlocked=li==0||passed.contains('$wi-${li-1}');return Padding(padding:const EdgeInsets.only(top:7),child:InkWell(borderRadius:BorderRadius.circular(15),onTap:unlocked?()=>_openLesson(wi,li):()=>_say('Complete the previous path first.'),child:Container(padding:const EdgeInsets.symmetric(horizontal:12,vertical:11),decoration:BoxDecoration(color:Colors.white.withOpacity(.78),borderRadius:BorderRadius.circular(15)),child:Row(children:[CircleAvatar(backgroundColor:done?green:Colors.white,child:Icon(done?Icons.check:unlocked?Icons.play_arrow:Icons.lock,color:ink)),const SizedBox(width:10),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Level ${li+1}: ${l.title}',style:const TextStyle(color:ink,fontWeight:FontWeight.w800)),Text(l.skill,style:const TextStyle(color:ink,fontSize:12))])),Icon(unlocked?Icons.chevron_right:Icons.lock_outline,color:ink)]))));})])));}
  Widget _buddy()=>Center(child:Padding(padding:const EdgeInsets.all(28),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[const Text('🦊',style:TextStyle(fontSize:120)),const Text('Pip the Fox',style:TextStyle(color:ink,fontWeight:FontWeight.w900,fontSize:27)),const Text('Your friendly learning buddy!',style:TextStyle(color:ink)),const SizedBox(height:18),FilledButton.icon(onPressed:()=>_say('Hello explorer! I am Pip. You are doing a wonderful job. Mistakes help our brains grow.'),icon:const Icon(Icons.volume_up),label:const Text('Hear Pip speak'))])));
  Widget _stickers()=>ListView(padding:const EdgeInsets.all(22),children:[const Text('STICKER COLLECTION',style:TextStyle(color:ink,fontWeight:FontWeight.w900,fontSize:19)),const Text('Earn stars by completing lessons. Keep exploring!',style:TextStyle(color:ink)),const SizedBox(height:18),Wrap(spacing:14,runSpacing:14,children:[for(int i=0;i<8;i++)Container(width:88,height:96,decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(18)),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Text(i<stars?'${['🌟','🦋','🌈','🏆','🌻','🚀','💎','🦉'][i]}':'🔒',style:const TextStyle(fontSize:35)),Text(i<stars?'Sticker ${i+1}':'Keep learning',style:const TextStyle(fontSize:10,color:ink))]))])]);
}

class LessonPage extends StatefulWidget {final QuestWorld world;final Lesson lesson;final String lessonKey;final Future<void> Function(int,String) onFinish;final Future<void> Function(String) speak;final bool sound;const LessonPage({super.key,required this.world,required this.lesson,required this.lessonKey,required this.onFinish,required this.speak,required this.sound});@override State<LessonPage> createState()=>_LessonPageState();}
class _LessonPageState extends State<LessonPage>{int index=0,score=0;String feedback='';bool completed=false,answered=false;Question get q=>widget.lesson.questions[index];void _answer(String value){final right=value==q.answer;setState(() { answered=true; feedback=right?'Wonderful! You did it! ⭐':'Good try! Learning takes practice. Try again or ask Pip for a hint.'; });if(right){score++;widget.speak('That is correct! ${q.mascotLine}');}else{widget.speak('Good try. ${q.hint}');}}
Future<void> _next()async{if(index<widget.lesson.questions.length-1){setState(() { index++; feedback=''; answered=false; });}else{await widget.onFinish(score,widget.lessonKey);if(mounted)setState(()=>completed=true);widget.speak('Quest complete! You earned $score stars. I am proud of you!');}}
@override Widget build(BuildContext context){if(completed)return Scaffold(appBar:AppBar(title:Text(widget.lesson.title)),body:Center(child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[const Text('🎉',style:TextStyle(fontSize:90)),const Text('LEVEL COMPLETE!',style:TextStyle(color:ink,fontSize:27,fontWeight:FontWeight.w900)),Text('You earned $score stars!',style:const TextStyle(color:ink,fontSize:20)),const SizedBox(height:18),FilledButton(onPressed:()=>Navigator.pop(context),child:const Text('Back to learning map'))])));return Scaffold(appBar:AppBar(title:Text(widget.lesson.title),actions:[IconButton(onPressed:()=>widget.speak('${q.prompt}. ${q.choices.join(', ')}'),icon:const Icon(Icons.volume_up))]),body:Padding(padding:const EdgeInsets.all(20),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[LinearProgressIndicator(value:(index+1)/widget.lesson.questions.length,minHeight:9,borderRadius:BorderRadius.circular(9)),const SizedBox(height:15),Text('QUESTION ${index+1} OF ${widget.lesson.questions.length}',textAlign:TextAlign.center,style:const TextStyle(color:green,fontWeight:FontWeight.w900)),const SizedBox(height:14),const Center(child:Text('🦊',style:TextStyle(fontSize:55))),Text(q.prompt,textAlign:TextAlign.center,style:const TextStyle(color:ink,fontSize:23,fontWeight:FontWeight.w900)),const SizedBox(height:22),for(final choice in q.choices)Padding(padding:const EdgeInsets.only(bottom:10),child:OutlinedButton(onPressed:answered?null:()=>_answer(choice),style:OutlinedButton.styleFrom(padding:const EdgeInsets.all(15),side:const BorderSide(color:green,width:1.5),backgroundColor:Colors.white),child:Text(choice,style:const TextStyle(color:ink,fontSize:21,fontWeight:FontWeight.bold)))),const Spacer(),if(feedback.isNotEmpty)Container(padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:answered&&feedback.startsWith('Wonderful')?const Color(0xFFDDF1D6):const Color(0xFFFFE7A8),borderRadius:BorderRadius.circular(14)),child:Text(feedback,textAlign:TextAlign.center,style:const TextStyle(color:ink,fontWeight:FontWeight.bold))),if(!answered)OutlinedButton.icon(onPressed:()=>widget.speak(q.hint),icon:const Icon(Icons.lightbulb_outline),label:const Text('Ask Pip for a hint')),if(answered&&feedback.startsWith('Wonderful'))FilledButton(onPressed:_next,child:Text(index==widget.lesson.questions.length-1?'Finish level':'Next question'))])));}}

class ParentPage extends StatelessWidget {final String nickname;final int stars,completed,ageBand;final bool sound;final VoidCallback onSound;final ValueChanged<String> onName;final VoidCallback onUpdate;const ParentPage({super.key,required this.nickname,required this.stars,required this.completed,required this.ageBand,required this.sound,required this.onSound,required this.onName,required this.onUpdate});@override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(20),children:[const Text('PARENT CORNER',style:TextStyle(color:ink,fontSize:20,fontWeight:FontWeight.w900)),const Text('A simple place for grown-ups to guide learning.',style:TextStyle(color:ink)),const SizedBox(height:18),Card(color:Colors.white,elevation:0,child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Learning snapshot',style:TextStyle(color:ink,fontWeight:FontWeight.w900,fontSize:18)),const SizedBox(height:10),Text('Child profile: $nickname',style:const TextStyle(color:ink)),Text('Age path: ${['3–5','6–8','9–11'][ageBand]}',style:const TextStyle(color:ink)),Text('Levels completed: $completed',style:const TextStyle(color:ink)),Text('Stars earned: $stars',style:const TextStyle(color:ink))]))),Card(color:Colors.white,elevation:0,child:Column(children:[ListTile(leading:const Icon(Icons.edit,color:ink),title:const Text('Child nickname'),subtitle:Text(nickname),onTap:()async{final c=TextEditingController(text:nickname);final v=await showDialog<String>(context:context,builder:(d)=>AlertDialog(title:const Text('Child nickname'),content:TextField(controller:c),actions:[TextButton(onPressed:()=>Navigator.pop(d),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(d,c.text.trim()),child:const Text('Save'))]));if(v!=null&&v.isNotEmpty)onName(v);}),SwitchListTile(value:sound,onChanged:(_)=>onSound(),title:const Text('Character voice & sound'),secondary:const Icon(Icons.volume_up,color:ink)),ListTile(leading:const Icon(Icons.system_update,color:ink),title:const Text('Check for app updates'),subtitle:const Text('Look for the latest Little Quest version'),onTap:onUpdate)])),const SizedBox(height:12),const Text('Child safety & privacy',style:TextStyle(color:ink,fontWeight:FontWeight.w900,fontSize:18)),const Text('This prototype stores learning progress on this device. It does not create child accounts or send progress to a server. No third-party advertising is included. Before public release, parental consent, a full privacy policy, data deletion controls and independent child-safety review must be completed.',style:TextStyle(color:ink,height:1.45)),const SizedBox(height:10),const Text('Parent gate is a basic prototype check, not secure identity verification. Please supervise young children while using this test version.',style:TextStyle(color:Colors.deepOrange,height:1.4))]);}

class UpdatePage extends StatefulWidget {const UpdatePage({super.key});@override State<UpdatePage> createState()=>_UpdatePageState();}
class _UpdatePageState extends State<UpdatePage>{bool loading=false;String status='Check GitHub for the latest Little Quest release.';String? url;Future<void> check()async{setState(() { loading=true; status='Checking for updates...'; });try{final r=await http.get(Uri.parse('https://api.github.com/repos/Abubakkar38133/version-0.1/releases/latest'),headers:{'Accept':'application/vnd.github+json'});if(r.statusCode==200){final j=jsonDecode(r.body) as Map<String,dynamic>;final assets=(j['assets'] as List? ?? []);final apk=assets.cast<Map<String,dynamic>>().where((a)=>(a['name'] as String).endsWith('.apk')).toList();if(apk.isNotEmpty){url=apk.first['browser_download_url'] as String;status='A release is available: ${j['tag_name']}. Tap Download update, then approve Android installation.';}else{status='A release was found, but no APK is attached yet.';}}else if(r.statusCode==404){status='No published update is available yet.';}else{status='Could not check right now. Please try again later.';}}catch(_){status='No internet connection or GitHub could not be reached.';}if(mounted)setState(()=>loading=false);}
Future<void> download()async{if(url==null)return;final u=Uri.parse(url!);if(await canLaunchUrl(u))await launchUrl(u,mode:LaunchMode.externalApplication);else setState(()=>status='Could not open the download link.');}
@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('App updates')),body:Padding(padding:const EdgeInsets.all(22),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[const Icon(Icons.system_update_alt,size:70,color:green),const Text('Keep Little Quest up to date',textAlign:TextAlign.center,style:TextStyle(color:ink,fontWeight:FontWeight.w900,fontSize:22)),const SizedBox(height:15),Text(status,textAlign:TextAlign.center,style:const TextStyle(color:ink)),const SizedBox(height:20),FilledButton(onPressed:loading?null:check,child:Text(loading?'Checking...':'Check for updates')),if(url!=null)FilledButton.tonal(onPressed:download,child:const Text('Download update')),const Spacer(),const Text('Updates are downloaded from the official project release page. Android will ask you to confirm installation.',textAlign:TextAlign.center,style:TextStyle(color:ink,fontSize:12))])));}}
