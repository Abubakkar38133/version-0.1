# Little Quest v0.2 upgrade bundle

This is the next MVP source update for the existing GitHub project.

## Included
- Three illustrated-by-emoji learning worlds: English Garden, Number Mountain, Wonder Woods
- Three learning levels per world (27 short questions total)
- A visual level path with sequential unlocks
- Pip the Fox voice using the device's built-in English text-to-speech
- Read-aloud question and hint controls
- Gentle retry feedback, stars and sticker collection
- Parent Corner with local progress summary, sound control and privacy notes
- Update-check screen that looks for the latest GitHub Release and opens the APK download

## Important limitations
- Pip currently uses the phone's built-in text-to-speech voice, not a recorded custom character voice.
- The world artwork uses emoji placeholders, not final original 2.5D illustrations.
- The age band is collected for the child profile, but this prototype still uses a shared starter curriculum; differentiated curricula need further authoring and testing.
- Parent gate is a simple prototype arithmetic check, not secure parental verification.
- Progress is stored locally. No accounts, cloud sync, advertising, payments or analytics are included.
- The update screen depends on publishing APK files as GitHub Releases.

## GitHub upload
Replace these two files in your repository:
- `app/lib/main.dart`
- `app/pubspec.yaml`

Then the GitHub Actions build can compile the updated app. The workflow must include Android internet permission and publish the resulting APK as a GitHub Release for the in-app update checker to find it.

## Update compatibility
Android updates require the same application ID and the same signing certificate. The current first test APK was built without a persistent signing key. The next release must establish a persistent private signing key. That means the currently installed test APK may need one uninstall/reinstall when moving to the first persistently signed release; subsequent releases can update in place. Never publish the keystore or passwords in a public repository.
